use crate::core::ids::{ChaseId, ClipId, CueId, FixtureGroupId, FxId, TrackId};
use crate::core::state::{
    AutomationInterpolation, AutomationTarget, ClipInlineParameterKind, ContextMenuAction,
    FxWaveform, InputModifiersState, SnapResolution,
};
use crate::core::time::BeatTime;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum AppEvent {
    Tick,
    Undo,
    Redo,
    RefreshVentures,
    SelectVenture(String),
    SelectRecoverySlot(String),
    SetVentureDraftName(String),
    SaveCurrentVenture,
    SaveCurrentVentureAs,
    RenameSelectedVenture,
    LoadSelectedVenture,
    DeleteSelectedVenture,
    RestoreSelectedRecoverySlot,
    AutosaveRecoverySlot(String),
    CreateNewVenture,
    DuplicateSelectedClips,
    SplitSelectedClipsAtPlayhead,
    DeleteSelectedClips,
    CopySelectedClips,
    CutSelectedClips,
    PasteClipboardAtPlayhead,
    NudgeSelectedClipsLeft,
    NudgeSelectedClipsRight,
    ToggleTransport,
    SetMasterIntensity(u16),
    SetMasterSpeed(u16),
    SetTimelineZoom(u16),
    SetInputModifiers(InputModifiersState),
    CloseContextMenu,
    ApplyContextMenuAction(ContextMenuAction),
    ToggleTrackMute(TrackId),
    ToggleTrackSolo(TrackId),
    ArmCue(CueId),
    TriggerCue(CueId),
    ToggleChase(ChaseId),
    ReverseChase(ChaseId),
    SelectFx(FxId),
    ToggleFx(FxId),
    SetFxDepth(FxId, u16),
    SetFxRate(FxId, u16),
    SetFxSpread(FxId, u16),
    SetFxPhaseOffset(FxId, u16),
    SetFxWaveform(FxId, FxWaveform),
    SelectFixtureGroup(FixtureGroupId),
    OpenClipEditor(ClipId),
    CloseClipEditor,
    SetClipEditorIntensity(u16),
    SetClipEditorSpeed(u16),
    SetClipEditorFxDepth(u16),
    SetClipEditorCue(Option<CueId>),
    SetClipEditorChase(Option<ChaseId>),
    SetClipEditorGrid(SnapResolution),
    SetClipEditorAutomationTarget(AutomationTarget),
    SetClipEditorAutomationMode(AutomationInterpolation),
    ToggleClipEditorAutomationLane,
    AddClipEditorAutomationPointAtPlayhead,
    SelectClipEditorAutomationPoint(Option<usize>),
    SetClipEditorAutomationPointValue(u16),
    NudgeClipEditorAutomationPointLeft,
    NudgeClipEditorAutomationPointRight,
    DeleteClipEditorAutomationPoint,
    Timeline(TimelineEvent),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum TimelineEvent {
    PointerMoved(TimelineCursor),
    PointerPressed(TimelineCursor),
    SecondaryPressed(TimelineCursor),
    PointerReleased(TimelineCursor),
    PointerExited,
    Scrolled {
        delta_lines: i16,
        anchor_x_px: i32,
        anchor_beat: BeatTime,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct TimelineCursor {
    pub beat: BeatTime,
    pub track: Option<TrackId>,
    pub zone: TimelineZone,
    pub target: Option<TimelineHit>,
    pub x_px: i32,
    pub y_px: i32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TimelineZone {
    Header,
    Track,
    Empty,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TimelineHit {
    ContextAction(ContextMenuAction),
    Playhead,
    ClipBody(ClipId),
    ClipStartHandle(ClipId),
    ClipEndHandle(ClipId),
    ClipCueHotspot(ClipId, CueId),
    ClipChaseHotspot(ClipId, ChaseId),
    ClipFxHotspot(ClipId, FxId),
    ClipParamHandle(ClipId, ClipInlineParameterKind),
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum StateDiff {
    StateLifecycle,
    EventQueue,
    History,
    Venture,
    Engine,
    Master,
    Input,
    TimelineViewport,
    TimelinePhase,
    Selection,
    Hover,
    ClipGeometry(ClipId),
    TrackMix(TrackId),
    SnapGuide,
    Playhead,
    ClipEditor,
    ContextMenu,
    Clipboard,
    ReplayLog,
    Cue(CueId),
    Chase(ChaseId),
    Fx(FxId),
    Fixture(FixtureGroupId),
    Performance,
    Validation,
}

impl StateDiff {
    pub fn label(&self) -> String {
        match self {
            Self::StateLifecycle => "state".to_owned(),
            Self::EventQueue => "queue".to_owned(),
            Self::History => "history".to_owned(),
            Self::Venture => "venture".to_owned(),
            Self::Engine => "engine".to_owned(),
            Self::Master => "master".to_owned(),
            Self::Input => "input".to_owned(),
            Self::TimelineViewport => "timeline".to_owned(),
            Self::TimelinePhase => "timeline-phase".to_owned(),
            Self::Selection => "selection".to_owned(),
            Self::Hover => "hover".to_owned(),
            Self::ClipGeometry(id) => format!("clip#{}", id.0),
            Self::TrackMix(id) => format!("track#{}", id.0),
            Self::SnapGuide => "snap".to_owned(),
            Self::Playhead => "playhead".to_owned(),
            Self::ClipEditor => "clip-editor".to_owned(),
            Self::ContextMenu => "context-menu".to_owned(),
            Self::Clipboard => "clipboard".to_owned(),
            Self::ReplayLog => "replay-log".to_owned(),
            Self::Cue(id) => format!("cue#{}", id.0),
            Self::Chase(id) => format!("chase#{}", id.0),
            Self::Fx(id) => format!("fx#{}", id.0),
            Self::Fixture(id) => format!("fixture#{}", id.0),
            Self::Performance => "perf".to_owned(),
            Self::Validation => "validation".to_owned(),
        }
    }
}
