use crate::core::automation::effective_clip_parameters;
use crate::core::event::StateDiff;
use crate::core::ids::{ChaseId, CueId, FixtureGroupId, FxId};
use crate::core::state::{
    ChaseDirection, ChasePhase, CuePhase, CueVisualState, FixturePhase, FxPhase, FxWaveform,
    StudioState,
};
use crate::core::time::{BeatTime, SpeedRatio};
use std::f32::consts::TAU;

pub fn arm_cue(state: &mut StudioState, cue_id: CueId) -> Vec<StateDiff> {
    let Some(index) = state
        .cue_system
        .cues
        .iter()
        .position(|cue| cue.id == cue_id)
    else {
        return Vec::new();
    };

    state.cue_system.selected = Some(cue_id);
    if !matches!(state.cue_system.cues[index].phase, CuePhase::Active) {
        state.cue_system.cues[index].phase = CuePhase::Armed;
        state.cue_system.cues[index].elapsed = BeatTime::ZERO;
    }

    sync_clip_cue_states(state);
    refresh_fixture_groups(state);

    vec![StateDiff::Cue(cue_id)]
}

pub fn trigger_cue(state: &mut StudioState, cue_id: CueId) -> Vec<StateDiff> {
    trigger_cue_internal(state, cue_id)
}

pub fn toggle_chase(state: &mut StudioState, chase_id: ChaseId) -> Vec<StateDiff> {
    let Some(index) = state
        .chase_system
        .chases
        .iter()
        .position(|chase| chase.id == chase_id)
    else {
        return Vec::new();
    };

    state.chase_system.selected = Some(chase_id);
    let mut cue_to_trigger = None;

    {
        let chase = &mut state.chase_system.chases[index];
        match chase.phase {
            ChasePhase::Playing | ChasePhase::Looping | ChasePhase::Reversing => {
                chase.phase = ChasePhase::Stopped;
                chase.progress = BeatTime::ZERO;
            }
            ChasePhase::Idle | ChasePhase::Stopped => {
                chase.phase = match chase.direction {
                    ChaseDirection::Forward => ChasePhase::Playing,
                    ChaseDirection::Reverse => ChasePhase::Reversing,
                };
                chase.progress = BeatTime::ZERO;
                cue_to_trigger = chase
                    .steps
                    .get(chase.current_step)
                    .and_then(|step| step.cue_id);
            }
        }
    }

    let mut diffs = vec![StateDiff::Chase(chase_id)];
    if let Some(cue_id) = cue_to_trigger {
        diffs.extend(trigger_cue_internal(state, cue_id));
    } else {
        refresh_fixture_groups(state);
    }

    diffs
}

pub fn reverse_chase(state: &mut StudioState, chase_id: ChaseId) -> Vec<StateDiff> {
    let Some(index) = state
        .chase_system
        .chases
        .iter()
        .position(|chase| chase.id == chase_id)
    else {
        return Vec::new();
    };

    state.chase_system.selected = Some(chase_id);
    let chase = &mut state.chase_system.chases[index];
    chase.direction = match chase.direction {
        ChaseDirection::Forward => ChaseDirection::Reverse,
        ChaseDirection::Reverse => ChaseDirection::Forward,
    };
    chase.phase = match chase.direction {
        ChaseDirection::Forward => ChasePhase::Playing,
        ChaseDirection::Reverse => ChasePhase::Reversing,
    };
    chase.progress = BeatTime::ZERO;

    vec![StateDiff::Chase(chase_id)]
}

pub fn select_fx(state: &mut StudioState, fx_id: FxId) -> Vec<StateDiff> {
    if state.fx_system.layers.iter().any(|layer| layer.id == fx_id) {
        state.fx_system.selected = Some(fx_id);
        return vec![StateDiff::Fx(fx_id)];
    }

    Vec::new()
}

pub fn toggle_fx(state: &mut StudioState, fx_id: FxId) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.enabled = !layer.enabled;
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        layer.output_level = 0;
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn set_fx_depth(state: &mut StudioState, fx_id: FxId, depth_permille: u16) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.depth_permille = depth_permille.min(1000);
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn set_fx_rate(state: &mut StudioState, fx_id: FxId, rate_permille: u16) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.rate = SpeedRatio::from_permille(rate_permille);
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn set_fx_spread(state: &mut StudioState, fx_id: FxId, spread_permille: u16) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.spread_permille = spread_permille.min(1000);
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn set_fx_phase_offset(
    state: &mut StudioState,
    fx_id: FxId,
    phase_offset_permille: u16,
) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.phase_offset_permille = phase_offset_permille.min(1000);
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn set_fx_waveform(
    state: &mut StudioState,
    fx_id: FxId,
    waveform: FxWaveform,
) -> Vec<StateDiff> {
    let Some(index) = state
        .fx_system
        .layers
        .iter()
        .position(|layer| layer.id == fx_id)
    else {
        return Vec::new();
    };

    let layer = &mut state.fx_system.layers[index];
    layer.waveform = waveform;
    layer.phase = if layer.enabled {
        FxPhase::Processing
    } else {
        FxPhase::Idle
    };
    state.fx_system.selected = Some(fx_id);
    refresh_fixture_groups(state);

    vec![StateDiff::Fx(fx_id)]
}

pub fn select_fixture_group(
    state: &mut StudioState,
    fixture_group_id: FixtureGroupId,
) -> Vec<StateDiff> {
    if state
        .fixture_system
        .groups
        .iter()
        .any(|group| group.id == fixture_group_id)
    {
        state.fixture_system.selected = Some(fixture_group_id);
        return vec![StateDiff::Fixture(fixture_group_id)];
    }

    Vec::new()
}

pub fn advance_show_frame(state: &mut StudioState, delta: BeatTime) -> Vec<StateDiff> {
    let mut diffs = Vec::new();

    diffs.extend(advance_cues(state, delta));
    diffs.extend(advance_chases(state, delta));
    diffs.extend(advance_fx_layers(state));
    diffs.extend(refresh_fixture_groups(state));
    sync_clip_cue_states(state);

    diffs
}

fn trigger_cue_internal(state: &mut StudioState, cue_id: CueId) -> Vec<StateDiff> {
    let Some(target_index) = state
        .cue_system
        .cues
        .iter()
        .position(|cue| cue.id == cue_id)
    else {
        return Vec::new();
    };

    let mut diffs = Vec::new();

    for cue in &mut state.cue_system.cues {
        if cue.id == cue_id {
            cue.phase = CuePhase::Triggered;
            cue.elapsed = BeatTime::ZERO;
        } else if matches!(cue.phase, CuePhase::Active | CuePhase::Triggered) {
            cue.phase = CuePhase::Fading;
            cue.elapsed = BeatTime::ZERO;
            diffs.push(StateDiff::Cue(cue.id));
        } else if cue.phase == CuePhase::Fading {
            cue.elapsed = BeatTime::ZERO;
        }
    }

    state.cue_system.selected = Some(cue_id);
    state.cue_system.active = Some(state.cue_system.cues[target_index].id);
    diffs.push(StateDiff::Cue(cue_id));

    sync_clip_cue_states(state);
    diffs.extend(refresh_fixture_groups(state));
    diffs
}

fn advance_cues(state: &mut StudioState, delta: BeatTime) -> Vec<StateDiff> {
    let mut diffs = Vec::new();

    for cue in &mut state.cue_system.cues {
        let before = cue.phase;
        match cue.phase {
            CuePhase::Triggered => {
                cue.phase = CuePhase::Active;
                cue.elapsed = BeatTime::ZERO;
            }
            CuePhase::Fading => {
                cue.elapsed = cue.elapsed.saturating_add(delta);
                if cue.elapsed >= cue.fade_duration {
                    cue.phase = CuePhase::Stored;
                    cue.elapsed = BeatTime::ZERO;
                }
            }
            CuePhase::Stored | CuePhase::Armed | CuePhase::Active => {}
        }

        if cue.phase != before {
            diffs.push(StateDiff::Cue(cue.id));
        }
    }

    state.cue_system.active = state
        .cue_system
        .cues
        .iter()
        .find(|cue| matches!(cue.phase, CuePhase::Triggered | CuePhase::Active))
        .map(|cue| cue.id);

    diffs
}

fn advance_chases(state: &mut StudioState, delta: BeatTime) -> Vec<StateDiff> {
    let mut diffs = Vec::new();
    let mut triggered_cues = Vec::new();
    let clip_speeds = state
        .timeline
        .tracks
        .iter()
        .flat_map(|track| track.clips.iter())
        .map(|clip| {
            let local = state
                .engine
                .transport
                .playhead
                .saturating_sub(clip.start)
                .clamp(BeatTime::ZERO, clip.duration);
            let effective = effective_clip_parameters(clip, local);
            (clip.id, effective.speed.permille())
        })
        .collect::<Vec<_>>();

    for chase in &mut state.chase_system.chases {
        if !matches!(
            chase.phase,
            ChasePhase::Playing | ChasePhase::Looping | ChasePhase::Reversing
        ) {
            continue;
        }

        if chase.steps.is_empty() {
            chase.phase = ChasePhase::Stopped;
            diffs.push(StateDiff::Chase(chase.id));
            continue;
        }

        let scaled_delta = chase
            .linked_clip
            .and_then(|clip_id| {
                clip_speeds
                    .iter()
                    .find_map(|(id, speed)| (*id == clip_id).then_some(*speed))
            })
            .map(|speed| {
                BeatTime::from_ticks(((delta.ticks() as u64 * speed as u64) / 1000) as u32)
            })
            .unwrap_or(delta);

        chase.progress = chase.progress.saturating_add(scaled_delta);
        let mut changed = false;

        loop {
            let step_duration = chase.steps[chase.current_step].duration;
            if chase.progress < step_duration {
                break;
            }

            chase.progress = chase.progress.saturating_sub(step_duration);
            changed = true;

            match chase.direction {
                ChaseDirection::Forward => {
                    if chase.current_step + 1 < chase.steps.len() {
                        chase.current_step += 1;
                        chase.phase = ChasePhase::Playing;
                    } else if chase.loop_enabled {
                        chase.current_step = 0;
                        chase.phase = ChasePhase::Looping;
                    } else {
                        chase.phase = ChasePhase::Stopped;
                        chase.progress = BeatTime::ZERO;
                        break;
                    }
                }
                ChaseDirection::Reverse => {
                    if chase.current_step > 0 {
                        chase.current_step -= 1;
                        chase.phase = ChasePhase::Reversing;
                    } else if chase.loop_enabled {
                        chase.current_step = chase.steps.len().saturating_sub(1);
                        chase.phase = ChasePhase::Reversing;
                    } else {
                        chase.phase = ChasePhase::Stopped;
                        chase.progress = BeatTime::ZERO;
                        break;
                    }
                }
            }

            if let Some(cue_id) = chase.steps[chase.current_step].cue_id {
                triggered_cues.push(cue_id);
            }
        }

        if changed {
            diffs.push(StateDiff::Chase(chase.id));
        }
    }

    for cue_id in triggered_cues {
        diffs.extend(trigger_cue_internal(state, cue_id));
    }

    diffs
}

fn advance_fx_layers(state: &mut StudioState) -> Vec<StateDiff> {
    let enabled_count = state
        .fx_system
        .layers
        .iter()
        .filter(|layer| layer.enabled)
        .count();
    let clip_profiles = state
        .timeline
        .tracks
        .iter()
        .flat_map(|track| track.clips.iter())
        .map(|clip| {
            let local = state
                .engine
                .transport
                .playhead
                .saturating_sub(clip.start)
                .clamp(BeatTime::ZERO, clip.duration);
            let effective = effective_clip_parameters(clip, local);
            (
                clip.id,
                matches!(
                    clip.phase,
                    crate::core::ClipPhase::Triggered | crate::core::ClipPhase::Active
                ),
                effective.fx_depth.permille(),
                effective.speed.permille(),
            )
        })
        .collect::<Vec<_>>();
    let frame_index = state.performance.frame_index;
    let master_intensity = state.master.intensity.permille();
    let mut diffs = Vec::new();

    for layer in &mut state.fx_system.layers {
        let clip_state = layer.linked_clip.and_then(|clip_id| {
            clip_profiles.iter().find_map(|(id, active, depth, speed)| {
                (*id == clip_id).then_some((*active, *depth, *speed))
            })
        });
        let active_clip = clip_state.map(|(active, _, _)| active).unwrap_or(false);
        let clip_fx_depth = clip_state.map(|(_, depth, _)| depth).unwrap_or(1000);
        let clip_speed = clip_state.map(|(_, _, speed)| speed).unwrap_or(1000);
        let effective_rate = ((layer.rate.permille() as u32 * clip_speed as u32) / 1000)
            .clamp(SpeedRatio::MIN as u32, SpeedRatio::MAX as u32)
            as u16;

        let before_phase = layer.phase;
        let before_output = layer.output_level;
        let modulation = waveform_modulation(
            frame_index,
            effective_rate,
            layer.phase_offset_permille,
            layer.spread_permille,
            layer.waveform,
        );
        let base_depth = ((layer.depth_permille as u32 * clip_fx_depth as u32) / 1000) as u16;

        if !layer.enabled {
            layer.phase = FxPhase::Idle;
            layer.output_level = 0;
        } else if active_clip {
            layer.phase = if enabled_count > 1 {
                FxPhase::Composed
            } else {
                FxPhase::Applied
            };
            let base_output = (base_depth as u32 * master_intensity as u32) / 1000;
            let factor = 400u32 + ((modulation as u32 * 600u32) / 1000);
            layer.output_level = ((base_output * factor) / 1000) as u16;
        } else {
            layer.phase = FxPhase::Processing;
            let factor = 180u32 + ((modulation as u32 * 220u32) / 1000);
            layer.output_level = ((base_depth as u32 * factor) / 1000) as u16;
        }

        if layer.phase != before_phase || layer.output_level != before_output {
            diffs.push(StateDiff::Fx(layer.id));
        }
    }

    diffs
}

fn waveform_modulation(
    frame_index: u64,
    rate_permille: u16,
    phase_offset_permille: u16,
    spread_permille: u16,
    waveform: FxWaveform,
) -> u16 {
    let phase = (((frame_index as u128 * rate_permille as u128 * 7) / 5)
        + phase_offset_permille as u128)
        % 1000;
    let raw = match waveform {
        FxWaveform::Sine => {
            let radians = (phase as f32 / 1000.0) * TAU;
            ((radians.sin() * 0.5 + 0.5) * 1000.0).round() as u16
        }
        FxWaveform::Triangle => {
            if phase < 500 {
                (phase as u16) * 2
            } else {
                ((1000 - phase) as u16) * 2
            }
        }
        FxWaveform::Saw => phase as u16,
        FxWaveform::Pulse => {
            if phase < 320 {
                1000
            } else {
                180
            }
        }
    };

    let centered = raw as i32 - 500;
    (500 + (centered * spread_permille as i32) / 1000).clamp(0, 1000) as u16
}

fn refresh_fixture_groups(state: &mut StudioState) -> Vec<StateDiff> {
    let active_cues = state
        .cue_system
        .cues
        .iter()
        .map(|cue| {
            let output = cue
                .linked_clip
                .and_then(|clip_id| state.clip(clip_id))
                .map(|clip| {
                    let local = state
                        .engine
                        .transport
                        .playhead
                        .saturating_sub(clip.start)
                        .clamp(BeatTime::ZERO, clip.duration);
                    effective_clip_parameters(clip, local).intensity.permille()
                })
                .unwrap_or(state.master.intensity.permille());
            (
                cue.id,
                matches!(cue.phase, CuePhase::Triggered | CuePhase::Active),
                output,
            )
        })
        .collect::<Vec<_>>();
    let fx_outputs = state
        .fx_system
        .layers
        .iter()
        .map(|layer| (layer.id, layer.output_level))
        .collect::<Vec<_>>();
    let mut diffs = Vec::new();

    for group in &mut state.fixture_system.groups {
        let cue_drive = group
            .linked_cue
            .and_then(|cue_id| {
                active_cues
                    .iter()
                    .find_map(|(id, active, output)| (*id == cue_id && *active).then_some(*output))
            })
            .unwrap_or(0);
        let fx_output = group
            .linked_fx
            .and_then(|fx_id| {
                fx_outputs
                    .iter()
                    .find_map(|(id, output)| (*id == fx_id).then_some(*output))
            })
            .unwrap_or(0);

        let before_phase = group.phase;
        let before_output = group.output_level;

        if group.online == 0 {
            group.phase = FixturePhase::Error;
            group.output_level = 0;
        } else if cue_drive > 0 || fx_output > 0 {
            group.phase = FixturePhase::Active;
            group.output_level = cue_drive.max(fx_output);
        } else if group.phase == FixturePhase::Uninitialized {
            group.output_level = 0;
        } else {
            group.phase = FixturePhase::Mapped;
            group.output_level = (group.fixture_count as u16 * 20).min(400);
        }

        if group.phase != before_phase || group.output_level != before_output {
            diffs.push(StateDiff::Fixture(group.id));
        }
    }

    diffs
}

fn sync_clip_cue_states(state: &mut StudioState) {
    let cue_states = state
        .cue_system
        .cues
        .iter()
        .map(|cue| (cue.id, CueVisualState::from_phase(cue.phase)))
        .collect::<Vec<_>>();

    for track in &mut state.timeline.tracks {
        for clip in &mut track.clips {
            if let Some(cue_id) = clip.linked_cue {
                clip.cue_state = cue_states
                    .iter()
                    .find_map(|(id, visual)| (*id == cue_id).then_some(*visual))
                    .unwrap_or(CueVisualState::Inactive);
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::core::{ClipId, StudioState};

    #[test]
    fn trigger_cue_moves_previous_active_to_fading() {
        let mut state = StudioState::default();

        let diffs = trigger_cue(&mut state, CueId(3));

        assert!(diffs.contains(&StateDiff::Cue(CueId(1))));
        assert!(diffs.contains(&StateDiff::Cue(CueId(3))));
        assert_eq!(
            state.cue(CueId(1)).expect("cue exists").phase,
            CuePhase::Fading
        );
        assert_eq!(
            state.cue(CueId(3)).expect("cue exists").phase,
            CuePhase::Triggered
        );
        assert_eq!(
            state.clip(ClipId(201)).expect("clip exists").cue_state,
            CueVisualState::Active
        );
    }

    #[test]
    fn chase_advances_and_triggers_linked_cue() {
        let mut state = StudioState::default();
        state.chase_system.chases[0].current_step = 0;
        state.chase_system.chases[0].progress = BeatTime::ZERO;

        let diffs = advance_show_frame(&mut state, BeatTime::from_fraction(1, 2));

        assert!(
            diffs
                .iter()
                .any(|diff| matches!(diff, StateDiff::Chase(ChaseId(1))))
        );
        assert_eq!(
            state.chase(ChaseId(1)).expect("chase exists").current_step,
            1
        );
        assert_eq!(
            state.cue(CueId(1)).expect("cue exists").phase,
            CuePhase::Triggered
        );
    }

    #[test]
    fn fx_output_follows_master_intensity_for_active_clip() {
        let mut state = StudioState::default();
        state.timeline.tracks[0].clips[1].phase = crate::core::ClipPhase::Active;
        state.performance.frame_index = 24;

        let diffs = advance_fx_layers(&mut state);
        let layer = state.fx_layer(FxId(1)).expect("fx exists");
        let clip = state.clip(ClipId(102)).expect("clip exists");
        let effective_rate =
            ((layer.rate.permille() as u32 * clip.params.speed.permille() as u32) / 1000)
                .clamp(SpeedRatio::MIN as u32, SpeedRatio::MAX as u32) as u16;
        let modulation = waveform_modulation(
            24,
            effective_rate,
            layer.phase_offset_permille,
            layer.spread_permille,
            layer.waveform,
        );
        let base_depth =
            ((layer.depth_permille as u32 * clip.params.fx_depth.permille() as u32) / 1000) as u16;
        let base_output = (base_depth as u32 * state.master.intensity.permille() as u32) / 1000;
        let expected = ((base_output * (400 + ((modulation as u32 * 600) / 1000))) / 1000) as u16;

        assert!(
            diffs
                .iter()
                .any(|diff| matches!(diff, StateDiff::Fx(FxId(1))))
        );
        assert_eq!(layer.output_level, expected);
    }

    #[test]
    fn fx_waveform_settings_change_modulated_output_deterministically() {
        let mut state = StudioState::default();
        state.timeline.tracks[0].clips[1].phase = crate::core::ClipPhase::Active;
        state.performance.frame_index = 12;
        state.fx_system.layers[0].waveform = FxWaveform::Saw;
        state.fx_system.layers[0].spread_permille = 1000;
        state.fx_system.layers[0].phase_offset_permille = 500;

        advance_fx_layers(&mut state);

        let output = state.fx_layer(FxId(1)).expect("fx exists").output_level;
        assert!(output > 0);
        assert!(output <= 1000);
    }

    #[test]
    fn fixture_group_becomes_active_from_linked_sources() {
        let mut state = StudioState::default();
        trigger_cue(&mut state, CueId(1));
        state.fixture_system.groups[0].phase = FixturePhase::Mapped;
        state.fixture_system.groups[0].output_level = 0;
        state.fx_system.layers[0].output_level = 900;

        let diffs = refresh_fixture_groups(&mut state);

        assert!(
            diffs
                .iter()
                .any(|diff| matches!(diff, StateDiff::Fixture(FixtureGroupId(1))))
        );
        assert_eq!(
            state
                .fixture_group(FixtureGroupId(1))
                .expect("group exists")
                .phase,
            FixturePhase::Active
        );
    }
}
